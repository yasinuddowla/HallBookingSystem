<?php include('functions.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<title>Convention Hall Booking System</title>
	<link rel="stylesheet" type="text/css" href="includes/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="includes/style.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/fontawesome-all.min.css">
</head>
<body>
	
	<?php  nav();?>
	<br>
	<br>
	<br>
	<br>
	<main role="main" class="container">
			